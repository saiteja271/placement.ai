# Member 4 — UI, Profile Input and Testing datasets

All rows in these CSV files are synthetic demonstration data created for prototyping and testing. They are not live vacancies and should not be represented as real employer requirements.

## Files
- student_profiles.csv: example student profiles for form and integration testing.
- jobs_dataset.csv: sample job cards and matching attributes.
- eligibility_rules.csv: sample eligibility criteria; confirm with the team before use.
- job_skills.csv: normalized job-to-skill mapping for skill-gap views.
- preparation_roadmap.csv: example learning steps for missing skills.
- ui_test_cases.csv: QA checklist; fill in actual_result and status after running each test.

## Load with Pandas
```python
import pandas as pd

students = pd.read_csv("data/student_profiles.csv")
jobs = pd.read_csv("data/jobs_dataset.csv")
rules = pd.read_csv("data/eligibility_rules.csv")
skills = pd.read_csv("data/job_skills.csv")
roadmap = pd.read_csv("data/preparation_roadmap.csv")
tests = pd.read_csv("data/ui_test_cases.csv")
```

## Data notes
- List-valued fields such as `skills`, `required_skills`, and `degree_requirements` are separated by semicolons.
- Convert these strings to lists with `value.split(";")` before comparing individual values.
- These eligibility rules are simplified examples, not legal or hiring guidance.
- Do not use the sample profiles as real personal data.
